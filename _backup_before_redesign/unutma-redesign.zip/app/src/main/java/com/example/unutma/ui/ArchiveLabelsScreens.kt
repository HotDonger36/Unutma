package com.example.unutma.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import com.example.unutma.Label
import com.example.unutma.Note
import com.example.unutma.data.archiveLabel
import com.example.unutma.data.noteDisplayTitle
import com.example.unutma.data.parseBlocks
import com.example.unutma.data.previewLine
import com.example.unutma.ui.theme.C
import com.example.unutma.ui.theme.LABEL_COLOURS
import com.example.unutma.ui.theme.Ty
import com.example.unutma.ui.theme.labelColor

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 12.dp, end = 12.dp, top = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        IconBtn(UI.Back, "Back", onBack, tint = C.fg)
        Text(title, style = Ty.screenTitle, color = C.fg, modifier = Modifier.weight(1f))
        actions()
    }
}

// ─── Archive ─────────────────────────────────────────────────────────────────

@Composable
fun ArchiveScreen(
    notes: List<Note>,
    labels: List<Label>,
    archiveDays: Int,
    onBack: () -> Unit,
    onRestore: (Note) -> Unit,
    onDeleteForever: (Collection<Int>) -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    var actionsFor by remember { mutableStateOf<Note?>(null) }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmOne by remember { mutableStateOf<Note?>(null) }
    val now = System.currentTimeMillis()
    val dayMs = 24L * 60 * 60 * 1000

    Column(Modifier.fillMaxSize().background(C.bg)) {
        ScreenHeader("Archive", onBack) {
            if (notes.isNotEmpty()) Box {
                IconBtn(UI.More, "More options", { menu = true })
                UMenu(menu, { menu = false }, DpOffset((-4).dp, 4.dp)) {
                    UMenuItem("Empty archive", { menu = false; confirmEmpty = true }, color = C.danger)
                }
            }
        }
        Text(
            "Deleted notes are kept for ${archiveLabel(archiveDays)}, then removed. Change this in Settings.",
            style = Ty.rowSub, color = C.muted, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
        )
        if (notes.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("The archive is empty.", style = Ty.monoValue, color = C.muted)
            }
        } else LazyColumn(contentPadding = PaddingValues(start = 24.dp, end = 24.dp, bottom = 40.dp)) {
            items(notes, key = { it.id }) { n ->
                val blocks = remember(n) { parseBlocks(n) }
                val color = labelColor(labels.firstOrNull { it.id == n.labelId }?.color ?: "GREY")
                val deleted = n.deletedAt
                val left = if (deleted == null) null else ((deleted + archiveDays * dayMs - now) / dayMs).coerceAtLeast(0)
                Column(Modifier.fillMaxWidth().clickable { actionsFor = n }) {
                    Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Dot(color, modifier = Modifier.padding(top = 8.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(noteDisplayTitle(n, blocks), style = Ty.rowTitle, color = C.fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val p = if (n.isLocked) "Locked" else blocks.previewLine()
                            if (p.isNotEmpty()) Text(p, style = Ty.rowSub, color = C.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            when (left) { null -> "archived"; 0L -> "today"; 1L -> "1d left"; else -> "${left}d left" },
                            style = Ty.mono, color = C.muted, modifier = Modifier.padding(top = 3.dp),
                        )
                    }
                    HDivider()
                }
            }
        }
    }

    actionsFor?.let { n ->
        UDialog({ actionsFor = null }, noteDisplayTitle(n)) {
            DialogRow("Restore", { actionsFor = null; onRestore(n) }, UI.Restore)
            DialogRow("Delete forever", { actionsFor = null; confirmOne = n }, UI.Trash, color = C.danger, iconTint = C.danger)
        }
    }
    confirmOne?.let { n ->
        ConfirmDialog("Delete forever?", "This note and its pictures and voice clips can't be brought back.", "Delete", { onDeleteForever(listOf(n.id)) }, { confirmOne = null })
    }
    if (confirmEmpty) {
        ConfirmDialog("Empty the archive?", "All ${notes.size} archived notes will be deleted for good.", "Empty", { onDeleteForever(notes.map { it.id }) }, { confirmEmpty = false })
    }
}

// ─── Manage labels ───────────────────────────────────────────────────────────

@Composable
fun LabelsScreen(
    labels: List<Label>,
    counts: Map<Int, Int>,
    onBack: () -> Unit,
    onAdd: (name: String, color: String) -> Unit,
    onUpdate: (Label) -> Unit,
    onDelete: (Label) -> Unit,
    onMove: (Label, Int) -> Unit,
) {
    var newName by remember { mutableStateOf("") }
    val nextColor = LABEL_COLOURS.map { it.key }.firstOrNull { k -> labels.none { it.color == k } } ?: "PURPLE"
    var newColor by remember(nextColor) { mutableStateOf(nextColor) }
    var editing by remember { mutableStateOf<Label?>(null) }
    var deleting by remember { mutableStateOf<Label?>(null) }

    Column(Modifier.fillMaxSize().background(C.bg).imePadding()) {
        ScreenHeader("Labels", onBack)
        Text(
            "Each label becomes a coloured section on your notes screen.",
            style = Ty.rowSub, color = C.muted, modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
        )
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 24.dp)) {
            itemsIndexed(labels, key = { _, l -> l.id }) { i, l ->
                val color = labelColor(l.color)
                Column(Modifier.fillMaxWidth().clickable { editing = l }) {
                    Row(Modifier.heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Dot(color, 8.dp)
                        Text(l.name.uppercase(), style = Ty.section, color = color, modifier = Modifier.weight(1f))
                        Text((counts[l.id] ?: 0).toString(), style = Ty.mono, color = C.muted)
                        IconBtn(UI.Back, "Move up", { onMove(l, i - 1) }, enabled = i > 0, iconSize = 16.dp, modifier = Modifier.rotate90())
                        IconBtn(UI.Back, "Move down", { onMove(l, i + 1) }, enabled = i < labels.lastIndex, iconSize = 16.dp, modifier = Modifier.rotate270())
                    }
                    HDivider()
                }
            }
            item {
                Spacer(Modifier.height(24.dp))
                Text("NEW LABEL", style = Ty.settingsHeader, color = C.muted)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(labelColor(newColor), 8.dp)
                    Spacer(Modifier.width(12.dp))
                    UField(newName, { newName = it.take(24) }, "Name, e.g. Personal", Modifier.weight(1f))
                    TextButtonU("Add", { onAdd(newName.trim(), newColor); newName = "" }, enabled = newName.isNotBlank())
                }
                Spacer(Modifier.height(10.dp))
                SwatchRow(LABEL_COLOURS.map { it.key }, newColor, { newColor = it })
                Spacer(Modifier.height(40.dp))
            }
        }
    }

    editing?.let { l ->
        var name by remember(l.id) { mutableStateOf(l.name) }
        var color by remember(l.id) { mutableStateOf(l.color) }
        UDialog({ editing = null }, "Edit label") {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                UField(name, { name = it.take(24) }, "Name", Modifier.fillMaxWidth())
                HDivider()
                SwatchRow(LABEL_COLOURS.map { it.key }, color, { color = it })
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButtonU("Delete", { editing = null; deleting = l }, color = C.danger)
                Spacer(Modifier.weight(1f))
                TextButtonU("Cancel", { editing = null }, color = C.muted)
                TextButtonU("Save", { onUpdate(l.copy(name = name.trim().ifBlank { l.name }, color = color)); editing = null })
            }
        }
    }
    deleting?.let { l ->
        ConfirmDialog(
            "Delete “${l.name}”?",
            "Its notes are kept; they just won't have a label any more.",
            "Delete", { onDelete(l) }, { deleting = null },
        )
    }
}

private fun Modifier.rotate90() = this.rotate(90f)
private fun Modifier.rotate270() = this.rotate(270f)
