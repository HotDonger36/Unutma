package com.example.unutma.widget

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.unutma.Label
import com.example.unutma.Note
import com.example.unutma.data.Prefs
import com.example.unutma.data.Repo
import com.example.unutma.data.ThemeMode
import com.example.unutma.data.noteDisplayTitle
import com.example.unutma.data.parseBlocks
import com.example.unutma.data.previewLine
import com.example.unutma.ui.Dot
import com.example.unutma.ui.HDivider
import com.example.unutma.ui.ScreenHeader
import com.example.unutma.ui.theme.C
import com.example.unutma.ui.theme.Ty
import com.example.unutma.ui.theme.UnutmaTheme
import com.example.unutma.ui.theme.labelColor
import kotlinx.coroutines.launch

/** Opens when a note widget is added to the home screen: pick which note it shows. */
class WidgetConfigActivity : ComponentActivity() {
    companion object { const val EXTRA_PROVIDER = "provider" }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val mgr = AppWidgetManager.getInstance(this)
        val className = intent.getStringExtra(EXTRA_PROVIDER) ?: mgr.getAppWidgetInfo(widgetId)?.provider?.className
        val provider = try {
            Class.forName(className ?: "").getDeclaredConstructor().newInstance() as NoteWidgetBase
        } catch (_: Exception) { finish(); return }

        setContent {
            val settings by Prefs.get(this).state.collectAsState()
            val notes by remember { Repo.notes(this).observeActive() }.collectAsState(initial = emptyList())
            val labels by remember { Repo.labels(this).observeAll() }.collectAsState(initial = emptyList())
            val scope = rememberCoroutineScope()
            UnutmaTheme(darkTheme = settings.themeMode != ThemeMode.LIGHT, accentKey = settings.accentKey, textScale = settings.textSize.scale) {
                Column(Modifier.fillMaxSize().background(C.bg)) {
                    ScreenHeader(provider.pickerTitle, { finish() })
                    val eligible = notes.filter { provider.accepts(it) }.sortedByDescending { it.updatedAt }
                    if (eligible.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(40.dp), contentAlignment = Alignment.Center) {
                            Text(
                                if (provider is CountdownWidget) "No notes with a countdown or reminder yet." else "No checklists yet.",
                                style = Ty.monoValue, color = C.muted,
                            )
                        }
                    } else LazyColumn(contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)) {
                        items(eligible, key = { it.id }) { n ->
                            PickRow(n, labels) {
                                Prefs.get(this@WidgetConfigActivity).setWidgetNote(widgetId, n.id)
                                scope.launch {
                                    provider.renderAll(applicationContext, mgr, intArrayOf(widgetId))
                                    setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                                    finish()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PickRow(n: Note, labels: List<Label>, onClick: () -> Unit) {
    val label = labels.firstOrNull { it.id == n.labelId }
    val blocks = remember(n) { parseBlocks(n) }
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Dot(labelColor(label?.color ?: "GREY"), modifier = Modifier.padding(top = 8.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(noteDisplayTitle(n, blocks), style = Ty.rowTitle, color = C.fg, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val p = if (n.isLocked) "Locked" else blocks.previewLine()
                if (p.isNotEmpty()) Text(p, style = Ty.rowSub, color = C.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        HDivider()
    }
}
