package com.example.unutma.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ThemeMode(val label: String) { DARK("Dark"), LIGHT("Light"), SYSTEM("System") }

enum class SortOrder(val label: String) {
    NEWEST("Newest first"),
    OLDEST("Oldest first"),
    TITLE_AZ("Title A–Z"),
    TITLE_ZA("Title Z–A"),
    UPCOMING("Coming up first"),
}

enum class TextSize(val label: String, val scale: Float) {
    SMALL("Small", 0.9f), MEDIUM("Medium", 1f), LARGE("Large", 1.15f)
}

/** How long a deleted note waits in the archive before it is removed for good. */
val ARCHIVE_OPTIONS: List<Pair<Int, String>> = listOf(
    1 to "1 day", 3 to "3 days", 7 to "1 week", 14 to "2 weeks", 30 to "1 month",
)

fun archiveLabel(days: Int): String = ARCHIVE_OPTIONS.firstOrNull { it.first == days }?.second ?: "$days days"

data class Settings(
    val themeMode: ThemeMode = ThemeMode.DARK,   // the app starts in dark mode
    val accentKey: String = "PURPLE",
    val textSize: TextSize = TextSize.MEDIUM,
    val sortOrder: SortOrder = SortOrder.NEWEST,
    val archiveDays: Int = 7,
    val sound: Boolean = true,
    val vibration: Boolean = true,
)

/**
 * App settings, saved in SharedPreferences and exposed as a StateFlow so every screen
 * updates the moment something changes. Also readable from notification receivers and widgets.
 */
class Prefs private constructor(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<Settings> = _state
    val current: Settings get() = _state.value

    private fun load(): Settings = Settings(
        themeMode = enumOr(sp.getString("theme_mode", null), ThemeMode.DARK),
        accentKey = migrateAccent(sp.getString("accent_key", "PURPLE") ?: "PURPLE"),
        textSize = enumOr(sp.getString("text_size", null), TextSize.MEDIUM),
        sortOrder = when (val s = sp.getString("sort_order", null)) {
            null, "DEFAULT", "COLOR" -> SortOrder.NEWEST
            else -> enumOr(s, SortOrder.NEWEST)
        },
        archiveDays = sp.getInt("archive_days", 7),
        sound = sp.getBoolean("notif_sound", true),
        vibration = sp.getBoolean("notif_vibration", true),
    )

    fun update(change: (Settings) -> Settings) {
        val s = change(_state.value)
        sp.edit()
            .putString("theme_mode", s.themeMode.name)
            .putString("accent_key", s.accentKey)
            .putString("text_size", s.textSize.name)
            .putString("sort_order", s.sortOrder.name)
            .putInt("archive_days", s.archiveDays)
            .putBoolean("notif_sound", s.sound)
            .putBoolean("notif_vibration", s.vibration)
            .apply()
        _state.value = s
    }

    // Small key/value store for widgets ("which note does widget 12 show?").
    fun widgetNote(widgetId: Int): Int = sp.getInt("widget_$widgetId", -1)
    fun setWidgetNote(widgetId: Int, noteId: Int) = sp.edit().putInt("widget_$widgetId", noteId).apply()
    fun clearWidget(widgetId: Int) = sp.edit().remove("widget_$widgetId").apply()

    companion object {
        private const val PREFS = "unutma_prefs"
        @Volatile private var instance: Prefs? = null
        fun get(context: Context): Prefs =
            instance ?: synchronized(this) { instance ?: Prefs(context).also { instance = it } }

        private inline fun <reified T : Enum<T>> enumOr(name: String?, fallback: T): T =
            try { if (name == null) fallback else enumValueOf<T>(name) } catch (_: Exception) { fallback }

        /** Old accent keys from the previous settings screen map onto the new palette. */
        private fun migrateAccent(key: String): String = when (key) {
            "YELLOW" -> "AMBER"
            "ORANGE", "RED" -> "CORAL"
            "TEAL" -> "BLUE"
            else -> key
        }
    }
}
