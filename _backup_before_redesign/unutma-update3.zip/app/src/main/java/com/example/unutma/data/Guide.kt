package com.example.unutma.data

import android.content.Context
import com.example.unutma.Label
import com.example.unutma.NOTE_TYPE_LIST
import com.example.unutma.NOTE_TYPE_TEXT
import com.example.unutma.Note
import com.example.unutma.RESET_DAILY

/**
 * Built-in notes that explain the app. They are added once, the first time Unutma opens
 * (and again from Settings › About › Add the guide notes). Each note shows the feature it
 * explains: the checklist note is a real checklist, the countdown note has a countdown, and so on.
 * They are ordinary notes, so they can be edited or deleted like any other.
 */
object Guide {
    private const val FLAG = "guide_seeded"
    private const val DAY = 24L * 60 * 60 * 1000

    suspend fun seedIfNeeded(ctx: Context) {
        val p = Prefs.get(ctx)
        if (p.flag(FLAG)) return
        p.setFlag(FLAG, true)
        add(ctx)
    }

    private fun t(s: String) = TextBlock(text = s.trimIndent())
    private fun c(s: String, done: Boolean = false, indent: Int = 0, qty: Int? = null) =
        CheckBlock(text = s, checked = done, indent = indent, qty = qty)

    /** Adds the guide notes under a "Guide" label (re-using it if it already exists). */
    suspend fun add(ctx: Context) {
        val labels = Repo.labels(ctx)
        val guide = labels.all().firstOrNull { it.name.equals("Guide", ignoreCase = true) }
            ?: run {
                val pos = (labels.all().maxOfOrNull { it.position } ?: -1) + 1
                val id = labels.insert(Label(name = "Guide", color = "PURPLE", position = pos)).toInt()
                Label(id = id, name = "Guide", color = "PURPLE", position = pos)
            }
        val now = System.currentTimeMillis()

        fun note(title: String, blocks: List<Block>, type: String = NOTE_TYPE_TEXT) =
            Note(title = title, type = type, labelId = guide.id, description = serializeBlocks(blocks))

        // Saved last-to-first, so "Welcome" ends up at the top of the list.
        val notes = listOf(
            note("Welcome to Unutma", listOf(
                t("""
                    Unutma means **don't forget**. These guide notes show what the app can do — read them, try things in them, then delete them whenever you like.

                    • Tap **+** to write a note. Long-press **+** for a checklist, or to talk and have it written for you.
                    • Notes save themselves as you type. There's no Save button.
                    • Made a mistake? Use undo and redo at the top of a note.
                    • Tap a note to open it. Long-press a note to select several.

                    The other guide notes go into the details. Start with [[Checklists]].
                """),
            )).copy(isPinned = true),

            note("Checklists", listOf(
                t("Any note can mix text and checkboxes. Press Enter at the end of an item to start the next one; press Enter on an empty item to go back to normal text."),
                c("Tap a box to tick it", done = true),
                c("Drag the dots on the left to reorder"),
                c("Long-press a box for more options"),
                c("Like making this a sub-item", indent = 1),
                c("Or adding a quantity", indent = 1),
                c("Eggs", qty = 12),
                c("Tomatoes, 500 g"),
                t("The checkbox button in the toolbar turns the line you're on into a checkbox, and back. Next: [[Labels]]."),
            ), NOTE_TYPE_LIST),

            note("Morning routine", listOf(
                t("This checklist unticks itself every day. Set it up in ⋯ › Reset checklist (every day or every Monday), or use ⋯ › Untick all."),
                c("Drink a glass of water"),
                c("Take the keys"),
                c("Check the train times"),
            ), NOTE_TYPE_LIST).copy(resetMode = RESET_DAILY, lastResetAt = now),

            note("Labels", listOf(
                t("""
                    Labels group your notes. Each label becomes a coloured section on the notes screen, and a tab at the top so you can show just that label.

                    • Give a note a label with the chip above its title.
                    • Create, rename, recolour and reorder labels in ⋯ › Manage labels.
                    • Select several notes (long-press) to label, pin, archive or delete them together.

                    This note is in the **Guide** label. Next: [[Reminders and dates]].
                """),
            )),

            note("Reminders and dates", listOf(
                t("""
                    Tap the bell at the bottom of a note to set a reminder: later today, tomorrow, next week or any date and time. The notification has **Done** and **Snooze** buttons.

                    *Repeat until done* keeps reminding you every few minutes until you tap Done — handy for things you really can't forget.

                    Unutma also spots dates you type. Try writing: Call the dentist on Monday 09:30 — a "Remind me?" suggestion appears above the toolbar.

                    In ⋯ you'll also find:
                    • **Countdown** — shows "in 3d" on the list, like [[Trip countdown]].
                    • **Expires** — the note moves to the archive on that day, like [[This note expires]].

                    Dates that are coming up soon are shown in the label's colour on the notes screen.
                """),
            )),

            note("Trip countdown", listOf(
                t("This note counts down to a date and time. Tap the date under the title (or ⋯ › Countdown) to change it. Under a day away it counts the hours. You can also put a countdown on your home screen with the Countdown widget."),
            )).copy(countdownAt = Fmt0.at(now + 3 * DAY, 9)),

            note("This note expires", listOf(
                t("In a week this note moves to the archive by itself. Great for Wi-Fi codes, parking spots or anything you only need for a while. Change it in ⋯ › Expires."),
            )).copy(expiresAt = Fmt0.at(now + 7 * DAY, 23, 59)),

            note("Writing tricks", listOf(
                t("""
                    # Text sizes
                    Tap **N** in the toolbar to make the line you're on bigger: N1, N2, N3, then back to normal.
                    ## Like this N2
                    ### And this N3

                    Numbered lists: tap the list button, or type 1. and a space. Press Enter and the next number appears; press Enter on an empty number to stop.
                    1. Like this
                    2. And this

                    **Bold** and *italic*: select text and tap B or I, or type **two stars** or *one star* around words.

                    Maths: end a line with = and the answer appears.
                    Groceries 12,50 + 7,20 + 3 =
                    Split between 3: 22,7 / 3 =

                    Links: type the title of another note between double square brackets, or use ⋯ › Link a note. Put the cursor on a link to open it: [[Welcome to Unutma]]
                """),
            )),

            note("Pictures and voice", listOf(
                t("""
                    The picture button adds a photo where your cursor is — text goes above and below it.

                    Tap a picture and choose **Extract text** to copy the words from it into the note: receipts, tickets, whiteboards.

                    The microphone button records a voice note you can play back inside the note.

                    **Talk to create**: long-press + and choose Talk, or use the mic on the quick capture widget. Say "shopping list eggs, milk and bread" for a checklist, or "remind me to call the bank tomorrow at 10" for a note with a reminder.
                """),
            )),

            note("Keeping things safe", listOf(
                t("""
                    **Pin to the notification bar**: the pin at the top of a note keeps it in your notifications, where it can't be swiped away. Notes pinned there show a small pin on the list.

                    **Lock**: ⋯ › Lock hides a note behind your fingerprint or screen lock — in the list, widgets and notifications too.

                    **Archive**: deleted notes wait in ⋯ › Archive for a week before they're removed (change how long in Settings), so you can restore them.

                    **Share**: ⋯ › Share sends a note as text, a PDF or an image.
                """),
            )),

            note("Widgets and settings", listOf(
                t("""
                    Long-press your home screen, choose Widgets and find Unutma:
                    • **Quick capture** — new note, new checklist or talk.
                    • **Countdown** — days left until a note's date.
                    • **Small list** and **Checklist** — tick items right from the home screen.
                    • **Note** — keep a note in view.

                    In ⋯ › Settings you can change the theme (dark, light or system), the accent colour, text size, sort order, how long the archive keeps notes, and notification sound and vibration.

                    Finished with the guide? Select these notes and delete them. You can bring them back in Settings › About.
                """),
            )),
        )
        for (n in notes.asReversed()) Repo.save(ctx, n)
    }

    /** Local date at a fixed time of day. */
    private object Fmt0 {
        fun at(dayMs: Long, hour: Int, minute: Int = 0): Long = java.util.Calendar.getInstance().apply {
            timeInMillis = dayMs
            set(java.util.Calendar.HOUR_OF_DAY, hour); set(java.util.Calendar.MINUTE, minute)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}
