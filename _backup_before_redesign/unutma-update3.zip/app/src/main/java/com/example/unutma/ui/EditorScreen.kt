package com.example.unutma.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import com.example.unutma.Label
import com.example.unutma.NOTE_TYPE_LIST
import com.example.unutma.Note
import com.example.unutma.RESET_DAILY
import com.example.unutma.RESET_NONE
import com.example.unutma.RESET_WEEKLY
import com.example.unutma.data.AudioBlock
import com.example.unutma.data.CheckBlock
import com.example.unutma.data.ImageBlock
import com.example.unutma.data.Prefs
import com.example.unutma.data.Repo
import com.example.unutma.data.TextBlock
import com.example.unutma.data.noteDisplayTitle
import com.example.unutma.data.parseBlocks
import com.example.unutma.export.Exporter
import com.example.unutma.media.Images
import com.example.unutma.media.Ocr
import com.example.unutma.media.VoicePlayer
import com.example.unutma.media.VoiceRecorder
import com.example.unutma.notify.Notifier
import com.example.unutma.ui.theme.C
import com.example.unutma.ui.theme.GeistMono
import com.example.unutma.ui.theme.Ty
import com.example.unutma.ui.theme.swatch
import com.example.unutma.util.DateDetector
import com.example.unutma.util.DetectedDate
import com.example.unutma.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.toArgb
import androidx.compose.runtime.snapshotFlow

/** What to open: an existing note (id > 0) or a new one. */
data class EditorTarget(val noteId: Int, val type: String = "TEXT", val labelId: Int? = null, val title: String? = null)

@Composable
fun EditorScreen(
    target: EditorTarget,
    labels: List<Label>,
    allNotes: List<Note>,
    onBack: () -> Unit,
    onOpenLink: (String) -> Unit,
    onManageLabels: () -> Unit,
    unlock: (onSuccess: () -> Unit) -> Unit,
) {
    val ctx = LocalContext.current
    var state by remember(target) { mutableStateOf<EditorState?>(null) }

    LaunchedEffect(target) {
        val existing = if (target.noteId > 0) withContext(Dispatchers.IO) { Repo.notes(ctx).get(target.noteId) } else null
        if (target.noteId > 0 && existing == null) { onBack(); return@LaunchedEffect }
        val reset = existing?.let { Repo.resetIfDue(it) }
        if (reset != null) withContext(Dispatchers.IO) { Repo.save(ctx, reset, touch = false) }
        val base = reset ?: existing ?: Note(type = target.type, labelId = target.labelId, title = target.title.orEmpty())
        val blocks = if (existing == null) {
            if (target.type == NOTE_TYPE_LIST) listOf(CheckBlock()) else listOf(TextBlock())
        } else parseBlocks(base)
        state = EditorState(base, blocks).also { s ->
            if (existing == null) {
                // New note: start typing straight away (in the title if it came from a link, else the body).
                s.focus(s.items.first().id, 0)
            }
        }
    }

    val s = state
    Box(Modifier.fillMaxSize().background(C.bg)) {
        if (s != null) Editor(s, labels, allNotes, onBack, onOpenLink, onManageLabels, unlock)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Editor(
    s: EditorState,
    labels: List<Label>,
    allNotes: List<Note>,
    onBack: () -> Unit,
    onOpenLink: (String) -> Unit,
    onManageLabels: () -> Unit,
    unlock: (onSuccess: () -> Unit) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saveLock = remember { Mutex() }
    val label = labels.firstOrNull { it.id == s.note.labelId }
    val labelKey = label?.color
    val tint = if (label != null) swatch(labelKey).on(C.isDark) else C.accent

    // ─── Auto-save: a moment after every change, and when leaving ───
    suspend fun persist() = saveLock.withLock {
        withContext(NonCancellable + Dispatchers.IO) {
            val v = s.version
            if (v == s.savedVersion) return@withContext // nothing changed since the last save
            s.savedVersion = v
            if (s.isEmpty()) {
                if (s.note.id != 0 && s.mediaPaths().isEmpty()) {
                    Repo.deleteForever(ctx, listOf(s.note.id)) // an emptied note is not kept
                    s.note = s.note.copy(id = 0)
                }
                return@withContext
            }
            val saved = Repo.save(ctx, s.toNote())
            withContext(Dispatchers.Main) {
                s.note = s.note.copy(id = saved.id, createdAt = saved.createdAt, updatedAt = saved.updatedAt)
                s.saveStatus = "saved"
            }
        }
    }
    LaunchedEffect(s) {
        snapshotFlow { s.version }.drop(1).collectLatest {
            s.saveStatus = "editing"
            delay(450)
            persist()
        }
    }
    DisposableEffect(s) {
        onDispose {
            VoicePlayer.stop()
            Repo.scope.launch { persist() }
        }
    }
    BackHandler { onBack() }

    // ─── Permissions and pickers ───
    var afterNotifPermission by remember { mutableStateOf<(() -> Unit)?>(null) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (!ok) Toast.makeText(ctx, "Notifications are off for Unutma, so reminders can't show.", Toast.LENGTH_LONG).show()
        afterNotifPermission?.invoke(); afterNotifPermission = null
    }
    fun withNotifications(block: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) { afterNotifPermission = block; notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS) } else block()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val path = Images.import(ctx, uri)
            if (path != null) s.insertMedia(ImageBlock(path = path))
            else Toast.makeText(ctx, "Couldn't add that picture.", Toast.LENGTH_SHORT).show()
        }
    }

    val recorder = remember { VoiceRecorder(ctx) }
    var recording by remember { mutableStateOf(false) }
    var recordStart by remember { mutableLongStateOf(0L) }
    fun startRecording() {
        if (recorder.start()) { recording = true; recordStart = System.currentTimeMillis() }
        else Toast.makeText(ctx, "Couldn't start recording.", Toast.LENGTH_SHORT).show()
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else Toast.makeText(ctx, "Unutma needs the microphone to record voice notes.", Toast.LENGTH_LONG).show()
    }
    DisposableEffect(Unit) { onDispose { if (recorder.isRecording) recorder.cancel() } }

    // ─── Dialog flags ───
    var moreMenu by remember { mutableStateOf(false) }
    var labelDialog by remember { mutableStateOf(false) }
    var reminderDialog by remember { mutableStateOf(false) }
    var countdownDialog by remember { mutableStateOf(false) }
    var datePickDirect by remember { mutableStateOf(false) }   // opened by tapping the date in the note
    var reminderTimeEdit by remember { mutableStateOf(false) }
    var expiryDialog by remember { mutableStateOf(false) }
    var resetDialog by remember { mutableStateOf(false) }
    var linkDialog by remember { mutableStateOf(false) }
    var shareDialog by remember { mutableStateOf(false) }
    var deleteConfirm by remember { mutableStateOf(false) }

    fun updateNote(change: (Note) -> Note) { s.note = change(s.note); s.metaChanged() }

    // ─── Date detection: "Dentist on Monday 09:30" offers a reminder ───
    var suggestion by remember { mutableStateOf<DetectedDate?>(null) }
    var dismissed by remember { mutableStateOf(setOf<Long>()) }
    LaunchedEffect(s.version) {
        delay(700)
        val text = s.title.text + "\n" + s.items.joinToString("\n") { it.tfv.text }
        suggestion = withContext(Dispatchers.Default) { DateDetector.detect(text) }
    }

    val focusRequesters = remember { HashMap<Long, FocusRequester>() }
    val titleFocus = remember { FocusRequester() }
    LaunchedEffect(s.pendingFocus) {
        val id = s.pendingFocus ?: return@LaunchedEffect
        s.placeCursor(id, s.focusCursor)
        repeat(5) {
            try { focusRequesters[id]?.requestFocus(); s.pendingFocus = null; return@LaunchedEffect } catch (_: Exception) {}
            delay(40)
        }
        s.pendingFocus = null
    }

    val faint = C.faint
    val transformation = remember(faint, tint) { NoteTransformation(faint, tint, tint, math = true) }
    val checkTransformation = remember(faint, tint) { NoteTransformation(faint, tint, tint, math = false) }

    // Drag to reorder
    var dragId by remember { mutableStateOf<Long?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val heights = remember { HashMap<Long, Int>() }

    Column(Modifier.fillMaxSize().statusBarsPadding().windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))) {
        // ─── Top bar ───
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(UI.Back, "Back to notes", onBack, tint = C.fg)
            Spacer(Modifier.weight(1f))
            IconBtn(UI.Undo, "Undo", { s.undo() }, tint = C.fg, enabled = s.canUndo, iconSize = 18.dp)
            IconBtn(UI.Redo, "Redo", { s.redo() }, tint = C.fg, enabled = s.canRedo, iconSize = 18.dp)
            IconBtn(
                if (s.note.pinnedToBar) UI.PinBarBold else UI.PinBar,
                if (s.note.pinnedToBar) "Unpin from notification bar" else "Pin to notification bar",
                {
                    val pin = !s.note.pinnedToBar
                    if (pin) withNotifications { updateNote { it.copy(pinnedToBar = true) } } else updateNote { it.copy(pinnedToBar = false) }
                    Toast.makeText(ctx, if (pin) "Pinned to the notification bar" else "Removed from the notification bar", Toast.LENGTH_SHORT).show()
                },
                tint = if (s.note.pinnedToBar) tint else C.fg, iconSize = 18.dp,
            )
            Box {
                IconBtn(UI.More, "More options", { moreMenu = true }, tint = C.fg, iconSize = 18.dp)
                UMenu(moreMenu, { moreMenu = false }, DpOffset((-4).dp, 4.dp)) {
                    UMenuItem("Label", { moreMenu = false; labelDialog = true }, UI.Tag, trailing = label?.name)
                    UMenuItem("Countdown", { moreMenu = false; datePickDirect = false; countdownDialog = true }, UI.Calendar,
                        trailing = s.note.countdownAt?.let { Fmt.countdown(it) })
                    UMenuItem("Expires", { moreMenu = false; datePickDirect = false; expiryDialog = true }, UI.Hourglass, trailing = s.note.expiresAt?.let { Fmt.dayMonth(it) })
                    if (s.items.any { it.block is CheckBlock }) {
                        UMenuItem("Untick all", { moreMenu = false; s.uncheckAll() }, UI.Restore)
                        UMenuItem("Reset checklist", { moreMenu = false; resetDialog = true }, UI.Repeat,
                            trailing = when (s.note.resetMode) { RESET_DAILY -> "daily"; RESET_WEEKLY -> "weekly"; else -> null })
                    }
                    UMenuItem("Link a note", { moreMenu = false; linkDialog = true }, UI.Link)
                    UMenuDivider()
                    UMenuItem(if (s.note.isPinned) "Unpin from top" else "Pin to top", { moreMenu = false; updateNote { it.copy(isPinned = !it.isPinned) } }, UI.PinTop)
                    UMenuItem(if (s.note.isLocked) "Unlock" else "Lock", {
                        moreMenu = false
                        if (s.note.isLocked) unlock { updateNote { it.copy(isLocked = false) } } else updateNote { it.copy(isLocked = true) }
                    }, if (s.note.isLocked) UI.Unlock else UI.Lock)
                    UMenuItem("Share", { moreMenu = false; shareDialog = true }, UI.Share)
                    UMenuDivider()
                    UMenuItem("Archive", {
                        moreMenu = false
                        scope.launch { persist(); if (s.note.id != 0) Repo.archive(ctx, listOf(s.note.id), deleted = false); onBack() }
                    }, UI.Archive)
                    UMenuItem("Delete", { moreMenu = false; deleteConfirm = true }, UI.Trash, iconTint = C.danger, color = C.danger)
                }
            }
        }

        // ─── Content ───
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            Spacer(Modifier.height(4.dp))
            // Label chip
            if (label != null) Pill(label.name, tint, { labelDialog = true })
            else Pill("Add label", C.muted, { labelDialog = true }, dashed = true)
            Spacer(Modifier.height(10.dp))

            // Title
            Box {
                if (s.title.text.isEmpty()) Text("Title", style = Ty.editorTitle, color = C.faint)
                BasicTextField(
                    value = s.title,
                    onValueChange = { s.updateTitle(it.copy(text = it.text.replace("\n", " "))) },
                    textStyle = Ty.editorTitle.copy(color = C.fg),
                    cursorBrush = SolidColor(C.accent),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { s.items.firstOrNull { it.block is TextBlock || it.block is CheckBlock }?.let { s.focus(it.id, it.tfv.text.length) } }),
                    modifier = Modifier.fillMaxWidth().focusRequester(titleFocus).onFocusChanged { if (it.isFocused) s.focusedId = -1L },
                )
            }
            Spacer(Modifier.height(10.dp))
            MetaLine(
                s, tint,
                onReminder = { reminderTimeEdit = true },
                onNag = { reminderDialog = true },
                onCountdown = { datePickDirect = true; countdownDialog = true },
                onExpiry = { datePickDirect = true; expiryDialog = true },
            )
            Spacer(Modifier.height(20.dp))

            // Blocks
            s.items.forEachIndexed { index, item ->
                key(item.id) {
                    val dragging = dragId == item.id
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .onSizeChanged { heights[item.id] = it.height }
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer { translationY = if (dragging) dragOffset else 0f; alpha = if (dragging) 0.85f else 1f }
                            .padding(bottom = if (index < s.items.lastIndex) 12.dp else 0.dp)
                    ) {
                        when (val b = item.block) {
                            is TextBlock -> TextRow(
                                s, item, focusRequesters, transformation,
                                placeholder = if (s.items.size == 1) "Note" else null,
                            )
                            is CheckBlock -> CheckRow(
                                s, item, b, tint, focusRequesters, checkTransformation,
                                dragModifier = Modifier.pointerInput(item.id) {
                                    detectDragGestures(
                                        onDragStart = { dragId = item.id; dragOffset = 0f },
                                        onDragEnd = { dragId = null; dragOffset = 0f; s.moveDone() },
                                        onDragCancel = { dragId = null; dragOffset = 0f; s.moveDone() },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            dragOffset += amount.y
                                            val i = s.indexOf(item.id)
                                            if (dragOffset > 0 && i < s.items.lastIndex) {
                                                val h = heights[s.items[i + 1].id] ?: 0
                                                if (h > 0 && dragOffset > h / 2f) { s.move(i, i + 1); dragOffset -= h }
                                            } else if (dragOffset < 0 && i > 0) {
                                                val h = heights[s.items[i - 1].id] ?: 0
                                                if (h > 0 && -dragOffset > h / 2f) { s.move(i, i - 1); dragOffset += h }
                                            }
                                        },
                                    )
                                },
                            )
                            is ImageBlock -> ImageRow(b, onRemove = { s.remove(b.id) }, onExtract = {
                                Toast.makeText(ctx, "Reading the text…", Toast.LENGTH_SHORT).show()
                                Ocr.extract(ctx, b.path) { text ->
                                    if (text.isNullOrBlank()) Toast.makeText(ctx, "No text found in this picture.", Toast.LENGTH_SHORT).show()
                                    else s.insertTextAfter(b.id, text.trim())
                                }
                            })
                            is AudioBlock -> AudioRow(b, tint, onRemove = { s.remove(b.id) })
                        }
                    }
                }
            }
            // Tap the empty space below the note to keep writing.
            Box(
                Modifier.fillMaxWidth().heightIn(min = 160.dp).clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null,
                ) {
                    val last = s.items.lastOrNull { it.block is TextBlock || it.block is CheckBlock }
                    if (last != null) s.focus(last.id, last.tfv.text.length)
                }
            )
        }

        // ─── Suggestions above the toolbar ───
        val focusedItem = s.focusedId?.let { id -> s.items.firstOrNull { it.id == id } }
        val linkTitle = focusedItem?.let { if (it.tfv.selection.collapsed) linkAt(it.tfv.text, it.tfv.selection.start) else null }
        val sug = suggestion
        Column(Modifier.padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (linkTitle != null) {
                SuggestionChip(UI.External, buildAnnotatedString { append("Open "); withStyle(SpanStyle(color = C.fg)) { append(linkTitle) } }, tint, {
                    scope.launch { persist(); onOpenLink(linkTitle) }
                })
            } else if (sug != null && s.note.reminderAt == null && sug.at !in dismissed) {
                SuggestionChip(UI.Bell, buildAnnotatedString {
                    append("Remind me ")
                    withStyle(SpanStyle(color = C.fg, fontFamily = GeistMono)) { append(Fmt.dateTime(sug.at)) }
                    append("?")
                }, tint, { withNotifications { updateNote { it.copy(reminderAt = sug.at) } } }, onDismiss = { dismissed = dismissed + sug.at })
            }
        }

        // ─── Toolbar (or the recording bar) ───
        HDivider()
        if (recording) {
            var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) { while (true) { delay(250); now = System.currentTimeMillis() } }
            val secs = ((now - recordStart) / 1000).toInt()
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Dot(C.danger, 8.dp)
                Spacer(Modifier.width(10.dp))
                Text("Recording  %d:%02d".format(secs / 60, secs % 60), style = Ty.monoValue, color = C.fg, modifier = Modifier.weight(1f))
                TextButtonU("Cancel", { recorder.cancel(); recording = false }, color = C.muted)
                TextButtonU("Done", {
                    val r = recorder.stop(); recording = false
                    if (r != null) s.insertMedia(AudioBlock(path = r.first, durationMs = r.second))
                })
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ToolText("B", "Bold", TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp)) { s.wrap("**") }
                ToolText("I", "Italic", TextStyle(fontStyle = FontStyle.Italic, fontSize = 16.sp)) { s.wrap("*") }
                val level = s.headingLevelAtFocus()
                ToolText(if (level == 0) "N" else "N$level", "Text size: " + (if (level == 0) "normal" else "heading $level") + ". Tap to change",
                    TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp), active = level > 0, activeColor = tint) { s.cycleHeading() }
                IconBtn(UI.Numbered, "Numbered list", { s.toggleNumbered() }, tint = C.muted, iconSize = 18.dp)
                IconBtn(UI.Checkbox, "Checkbox", { s.toggleChecklistAtFocus() }, tint = C.muted, iconSize = 18.dp)
                IconBtn(UI.Image, "Add image", { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, tint = C.muted, iconSize = 18.dp)
                IconBtn(UI.Mic, "Voice note", {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                    else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }, tint = C.muted, iconSize = 18.dp)
                IconBtn(UI.Bell, if (s.note.reminderAt != null) "Reminder set" else "Reminder", { reminderDialog = true },
                    tint = if (s.note.reminderAt != null) tint else C.muted, iconSize = 18.dp)
            }
        }
    }

    // ─── Dialogs ───
    if (labelDialog) LabelPickerDialog(
        labels, s.note.labelId, { id -> updateNote { it.copy(labelId = id) } }, onManageLabels, { labelDialog = false },
        onCreate = { name, color ->
            scope.launch {
                val pos = (labels.maxOfOrNull { it.position } ?: -1) + 1
                val id = withContext(Dispatchers.IO) { Repo.labels(ctx).insert(Label(name = name, color = color, position = pos)).toInt() }
                updateNote { it.copy(labelId = id) }
            }
        },
    )
    if (reminderDialog) ReminderDialog(s.note.reminderAt, s.note.nagMinutes, { at, nag ->
        if (at != null) withNotifications { updateNote { it.copy(reminderAt = at, nagMinutes = nag) } }
        else { updateNote { it.copy(reminderAt = null, nagMinutes = 0) }; Notifier.cancelReminder(ctx, s.note.id) }
    }, { reminderDialog = false })
    if (countdownDialog) DateOrRemove(
        "Count down to", s.note.countdownAt,
        onSet = { at -> updateNote { it.copy(countdownAt = at) } },
        onRemove = { updateNote { it.copy(countdownAt = null) } },
        onDismiss = { countdownDialog = false }, hour = 9,
        withTime = true, openPicker = datePickDirect,
    )
    if (expiryDialog) DateOrRemove(
        "Expires on", s.note.expiresAt,
        onSet = { at -> updateNote { it.copy(expiresAt = at) } },
        onRemove = { updateNote { it.copy(expiresAt = null) } },
        onDismiss = { expiryDialog = false }, hour = 23, minute = 59,
        note = "On that day the note moves to the archive.",
        openPicker = datePickDirect,
    )
    // Tapping the reminder's date and time in the note opens the date and time picker straight away.
    if (reminderTimeEdit) s.note.reminderAt?.let { current ->
        DateTimePicker(current, withTime = true, onPicked = { at ->
            withNotifications { updateNote { it.copy(reminderAt = at) } }
            reminderTimeEdit = false
        }, onDismiss = { reminderTimeEdit = false })
    }
    if (resetDialog) OptionDialog(
        "Untick every box", listOf(RESET_NONE to "Never", RESET_DAILY to "Every day", RESET_WEEKLY to "Every Monday"), s.note.resetMode,
        { mode -> updateNote { it.copy(resetMode = mode, lastResetAt = System.currentTimeMillis()) } }, { resetDialog = false },
    )
    if (linkDialog) LinkPicker(allNotes.filter { it.id != s.note.id }, { title -> s.insertAtCursor("[[$title]]") }, { linkDialog = false })
    if (shareDialog) UDialog({ shareDialog = false }, "Share") {
        val n = s.toNote(); val blocks = s.blocks()
        val colorInt = swatch(labelKey ?: Prefs.get(ctx).current.accentKey).dark.toArgb()
        val dark = C.isDark
        DialogRow("As text", { shareDialog = false; Exporter.shareText(ctx, n, blocks) }, UI.Text)
        DialogRow("As PDF", { shareDialog = false; scope.launch { Exporter.sharePdf(ctx, n, blocks, label?.name, colorInt) } }, UI.Copy)
        DialogRow("As image", { shareDialog = false; scope.launch { Exporter.shareImage(ctx, n, blocks, label?.name, colorInt, dark) } }, UI.Image)
    }
    if (deleteConfirm) ConfirmDialog(
        "Delete note?", "It stays in the archive for a while, so you can still restore it.", "Delete",
        { scope.launch { persist(); if (s.note.id != 0) Repo.delete(ctx, listOf(s.note.id)); s.note = s.note.copy(id = 0); onBack() } },
        { deleteConfirm = false },
    )
}

/** Dates, times and status under the title. Tap a date or time to change it. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun MetaLine(
    s: EditorState,
    tint: Color,
    onReminder: () -> Unit,
    onNag: () -> Unit,
    onCountdown: () -> Unit,
    onExpiry: () -> Unit,
) {
    val n = s.note
    val parts = ArrayList<@Composable () -> Unit>()
    @Composable
    fun Seg(text: androidx.compose.ui.text.AnnotatedString, description: String?, onClick: (() -> Unit)?) {
        Text(
            text, style = Ty.mono, color = C.muted,
            modifier = if (onClick == null) Modifier else Modifier
                .clip(RoundedCornerShape(6.dp))
                .clickable(role = Role.Button, onClick = onClick)
                .semantics { if (description != null) contentDescription = description }
                .padding(vertical = 4.dp),
        )
    }
    n.reminderAt?.let { at ->
        parts += { Seg(buildAnnotatedString { withStyle(SpanStyle(color = tint)) { append(Fmt.dateTime(at)) } }, "Reminder ${Fmt.dateTime(at)}, tap to change", onReminder) }
        if (n.nagMinutes > 0) parts += { Seg(buildAnnotatedString { append("every ${n.nagMinutes} min") }, "Repeats every ${n.nagMinutes} minutes, tap to change", onNag) }
    }
    n.countdownAt?.let { at ->
        parts += {
            Seg(buildAnnotatedString {
                append(Fmt.dateTime(at)); append(" · ")
                withStyle(SpanStyle(color = if (Fmt.isSoon(at)) tint else C.muted)) { append(Fmt.countdown(at, long = true)) }
            }, "Countdown to ${Fmt.dateTime(at)}, tap to change", onCountdown)
        }
    }
    n.expiresAt?.let { at ->
        parts += { Seg(buildAnnotatedString { withStyle(SpanStyle(color = if (Fmt.isSoon(at, 3)) tint else C.muted)) { append("expires " + Fmt.dayMonth(at)) } }, "Expires ${Fmt.dayMonth(at)}, tap to change", onExpiry) }
    }
    val plain = buildList {
        if (n.resetMode == RESET_DAILY) add("resets daily")
        if (n.resetMode == RESET_WEEKLY) add("resets weekly")
        if (n.isLocked) add("locked")
        add(if (s.saveStatus == "saved") (if (n.id == 0) "new" else "saved") else "…")
    }
    plain.forEach { t -> parts += { Seg(buildAnnotatedString { append(t) }, null, null) } }

    FlowRow(verticalArrangement = Arrangement.Center, itemVerticalAlignment = Alignment.CenterVertically) {
        parts.forEachIndexed { i, part ->
            if (i > 0) Text(" · ", style = Ty.mono, color = C.muted)
            part()
        }
    }
}

@Composable
private fun TextRow(
    s: EditorState,
    item: EItem,
    frs: HashMap<Long, FocusRequester>,
    transformation: NoteTransformation,
    placeholder: String?,
) {
    val fr = frs.getOrPut(item.id) { FocusRequester() }
    Box(Modifier.fillMaxWidth()) {
        if (placeholder != null && item.tfv.text.isEmpty()) Text(placeholder, style = Ty.body, color = C.faint)
        BasicTextField(
            value = item.tfv,
            onValueChange = { s.edit(item.id, it) },
            textStyle = Ty.body.copy(color = C.body),
            cursorBrush = SolidColor(C.accent),
            visualTransformation = transformation,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            modifier = Modifier
                .fillMaxWidth()
                .focusRequester(fr)
                .onFocusChanged { if (it.isFocused) s.focusedId = item.id }
                .onPreviewKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyDown && ev.key == Key.Backspace && item.tfv.selection.collapsed && item.tfv.selection.start == 0) {
                        s.backspaceAtStart(item.id); true
                    } else false
                },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CheckRow(
    s: EditorState,
    item: EItem,
    b: CheckBlock,
    tint: Color,
    frs: HashMap<Long, FocusRequester>,
    transformation: NoteTransformation,
    dragModifier: Modifier,
) {
    val fr = frs.getOrPut(item.id) { FocusRequester() }
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().offset(x = (-18).dp).padding(start = (b.indent * 24).dp),
        verticalAlignment = Alignment.Top,
    ) {
        // Drag handle
        Box(
            Modifier.size(width = 18.dp, height = 26.dp).then(dragModifier).semantics { contentDescription = "Drag to reorder" },
            contentAlignment = Alignment.CenterStart,
        ) { Icon(UI.Drag, null, tint = C.faint, modifier = Modifier.size(width = 10.dp, height = 16.dp)) }
        // Checkbox (long-press for sub-item, quantity…)
        Box {
            Box(
                Modifier
                    .size(26.dp)
                    .combinedClickable(role = Role.Checkbox, onClick = { s.toggle(b.id) }, onLongClick = { menu = true })
                    .semantics { contentDescription = if (b.checked) "Done" else "Not done" },
                contentAlignment = Alignment.CenterStart,
            ) {
                Box(
                    Modifier
                        .size(14.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .then(if (b.checked) Modifier.background(tint) else Modifier.border(1.dp, C.muted, RoundedCornerShape(3.dp)))
                )
            }
            UMenu(menu, { menu = false }) {
                if (b.indent == 0) UMenuItem("Make sub-item", { menu = false; s.setIndent(b.id, 1) }, UI.Indent)
                else UMenuItem("Make main item", { menu = false; s.setIndent(b.id, 0) }, UI.Outdent)
                if (b.qty == null) UMenuItem("Add quantity", { menu = false; s.setQty(b.id, 1) }, UI.PlusBold)
                else UMenuItem("Remove quantity", { menu = false; s.setQty(b.id, null) }, UI.Minus)
                UMenuItem("Turn into text", { menu = false; s.toText(b.id) }, UI.Text)
                UMenuItem("Delete item", { menu = false; s.remove(b.id) }, UI.Trash, iconTint = C.danger, color = C.danger)
            }
        }
        BasicTextField(
            value = item.tfv,
            onValueChange = { if (it.text.contains('\n')) s.enterInCheck(item.id, it) else s.edit(item.id, it) },
            textStyle = Ty.body.copy(
                color = if (b.checked) C.done else C.body,
                textDecoration = if (b.checked) TextDecoration.LineThrough else null,
            ),
            cursorBrush = SolidColor(C.accent),
            visualTransformation = transformation,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
            modifier = Modifier
                .weight(1f)
                .focusRequester(fr)
                .onFocusChanged { if (it.isFocused) s.focusedId = item.id }
                .onPreviewKeyEvent { ev ->
                    if (ev.type == KeyEventType.KeyDown && ev.key == Key.Backspace && item.tfv.selection.collapsed && item.tfv.selection.start == 0) {
                        s.backspaceAtStart(item.id); true
                    } else false
                },
        )
        val q = b.qty
        if (q != null) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.offset(x = 18.dp)) {
                StepButton(UI.Minus, "Less") { s.setQty(b.id, (q - 1).coerceAtLeast(0)) }
                Text(q.toString(), style = Ty.monoValue, color = if (b.checked) C.done else C.fg, modifier = Modifier.widthIn(min = 22.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                StepButton(UI.PlusBold, "More") { s.setQty(b.id, q + 1) }
            }
        }
    }
}

@Composable
private fun StepButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(CircleShape).border(1.dp, C.menuBorder, CircleShape).clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = C.muted, modifier = Modifier.size(14.dp)) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImageRow(b: ImageBlock, onRemove: () -> Unit, onExtract: () -> Unit) {
    var bmp by remember(b.path) { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember(b.path) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(b.path) {
        val loaded = Images.load(b.path, 1440)
        if (loaded == null) failed = true else bmp = loaded.asImageBitmap()
    }
    Box {
        Box(
            Modifier
                .fillMaxWidth()
                .border(1.dp, C.menuBorder)
                .combinedClickable(onClick = { menu = true }, onLongClick = { menu = true })
                .semantics { contentDescription = "Picture. Tap for options" },
        ) {
            val img = bmp
            if (img != null) Image(img, null, Modifier.fillMaxWidth().aspectRatio(img.width.toFloat() / img.height.coerceAtLeast(1)), contentScale = ContentScale.Fit)
            else Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                Text(if (failed) "picture missing" else "loading picture…", style = Ty.mono, color = C.muted)
            }
        }
        UMenu(menu, { menu = false }) {
            UMenuItem("Extract text", { menu = false; onExtract() }, UI.TextScan)
            UMenuItem("Remove picture", { menu = false; onRemove() }, UI.Trash, iconTint = C.danger, color = C.danger)
        }
    }
}

@Composable
private fun AudioRow(b: AudioBlock, tint: Color, onRemove: () -> Unit) {
    var playing by remember(b.path) { mutableStateOf(VoicePlayer.playingPath == b.path) }
    var pos by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(playing) {
        while (playing) { pos = VoicePlayer.position(); delay(200); if (VoicePlayer.playingPath != b.path) playing = false }
        pos = 0
    }
    val total = b.durationMs.coerceAtLeast(1)
    Row(
        Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(12.dp)).border(1.dp, C.menuBorder, RoundedCornerShape(12.dp)).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBtn(if (playing) UI.Pause else UI.Play, if (playing) "Pause" else "Play voice note", {
            if (playing) { VoicePlayer.stop(); playing = false }
            else { VoicePlayer.play(b.path) { playing = false }; playing = true }
        }, tint = tint, iconSize = 18.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row {
                Text("Voice note", style = Ty.rowSub, color = C.fg, modifier = Modifier.weight(1f))
                val secs = ((if (playing) pos.toLong() else b.durationMs) / 1000).toInt()
                Text("%d:%02d".format(secs / 60, secs % 60), style = Ty.mono, color = C.muted)
            }
            Box(Modifier.fillMaxWidth().height(2.dp).background(C.track)) {
                Box(Modifier.fillMaxWidth((pos.toFloat() / total).coerceIn(0f, 1f)).height(2.dp).background(tint))
            }
        }
        Box {
            IconBtn(UI.More, "Voice note options", { menu = true }, iconSize = 16.dp)
            UMenu(menu, { menu = false }) {
                UMenuItem("Remove voice note", { menu = false; VoicePlayer.stop(); onRemove() }, UI.Trash, iconTint = C.danger, color = C.danger)
            }
        }
    }
}

@Composable
private fun ToolText(text: String, description: String, style: TextStyle, active: Boolean = false, activeColor: Color = C.accent, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 42.dp, height = 44.dp).clip(CircleShape).clickable(role = Role.Button, onClick = onClick).semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { Text(text, style = style.copy(fontFamily = com.example.unutma.ui.theme.Geist), color = if (active) activeColor else C.muted) }
}

@Composable
private fun SuggestionChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: androidx.compose.ui.text.AnnotatedString,
    tint: Color,
    onClick: () -> Unit,
    onDismiss: (() -> Unit)? = null,
) {
    Row(
        Modifier
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, tint.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .padding(start = 12.dp, end = if (onDismiss != null) 2.dp else 14.dp)
            .heightIn(min = 36.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(14.dp))
        Text(text, style = Ty.rowSub, color = C.muted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
        if (onDismiss != null) IconBtn(UI.Close, "Dismiss", onDismiss, iconSize = 14.dp, modifier = Modifier.size(36.dp))
    }
}

/** Date-only picker with a "Remove" option when a date is already set. */
@Composable
private fun DateOrRemove(
    title: String, current: Long?, onSet: (Long) -> Unit, onRemove: () -> Unit, onDismiss: () -> Unit,
    hour: Int, minute: Int = 0, note: String? = null,
    withTime: Boolean = false,      // pick a time too (countdowns)
    openPicker: Boolean = false,    // go straight to the date picker (tapped the date in the note)
) {
    var picking by remember { mutableStateOf(current == null || openPicker) }
    if (picking) {
        DateTimePicker(current ?: System.currentTimeMillis() + 24L * 60 * 60 * 1000, withTime = withTime, onPicked = { at ->
            if (withTime) onSet(at) else {
                val c = java.util.Calendar.getInstance().apply { timeInMillis = at; set(java.util.Calendar.HOUR_OF_DAY, hour); set(java.util.Calendar.MINUTE, minute) }
                onSet(c.timeInMillis)
            }
            onDismiss()
        }, onDismiss = { if (current == null || openPicker) onDismiss() else picking = false }, defaultHour = hour)
        return
    }
    UDialog(onDismiss, title) {
        if (current != null) Text(
            (if (withTime) Fmt.dateTime(current) + " · " + Fmt.countdown(current, long = true) else Fmt.date(current) + " · " + Fmt.relative(current, long = true)),
            style = Ty.mono, color = C.muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        if (note != null) Text(note, style = Ty.rowSub, color = C.muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        DialogRow(if (withTime) "Change date and time" else "Change date", { picking = true }, UI.Calendar)
        DialogRow("Remove", { onRemove(); onDismiss() }, UI.Close, color = C.danger, iconTint = C.danger)
    }
}

/** Pick a note to link to; inserts [[Title]]. */
@Composable
private fun LinkPicker(notes: List<Note>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val titled = remember(notes) { notes.map { it to noteDisplayTitle(it) }.sortedBy { it.second.lowercase() } }
    val shown = titled.filter { q.isBlank() || it.second.contains(q.trim(), ignoreCase = true) }.take(40)
    UDialog(onDismiss, "Link a note") {
        UField(q, { q = it }, "Search or type a new title", Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp))
        HDivider(modifier = Modifier.padding(horizontal = 20.dp))
        Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
            if (q.isNotBlank() && titled.none { it.second.equals(q.trim(), ignoreCase = true) }) {
                DialogRow("Link to new note “${q.trim()}”", { onPick(q.trim()); onDismiss() }, UI.PlusBold)
            }
            shown.forEach { (_, title) -> DialogRow(title, { onPick(title); onDismiss() }, UI.Link) }
        }
    }
}
