package com.example.unutma.notify

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.compose.ui.graphics.toArgb
import com.example.unutma.MainActivity
import com.example.unutma.Note
import com.example.unutma.R
import com.example.unutma.data.Prefs
import com.example.unutma.data.noteDisplayTitle
import com.example.unutma.data.parseBlocks
import com.example.unutma.data.plainText
import com.example.unutma.data.previewLine
import com.example.unutma.ui.theme.LABEL_COLOURS

object Notifier {
    const val CH_PIN = "pinned_notes_v2"
    private const val TAG_REMINDER = "reminder"
    private const val TAG_PIN = "pin"
    const val EXTRA_NOTE_ID = "note_id"

    private fun nm(ctx: Context) = ctx.getSystemService(NotificationManager::class.java)

    fun canPost(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    /**
     * Android does not let an app change a channel's sound or vibration after creating it,
     * so each Sound/Vibration combination from Settings gets its own channel.
     */
    fun reminderChannel(ctx: Context): String {
        val s = Prefs.get(ctx).current
        val id = "reminders_s${if (s.sound) 1 else 0}_v${if (s.vibration) 1 else 0}"
        if (Build.VERSION.SDK_INT >= 26) {
            val m = nm(ctx)
            if (m.getNotificationChannel(id) == null) {
                val ch = NotificationChannel(id, "Reminders", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Reminders you set on notes"
                    if (!s.sound) setSound(null, null)
                    enableVibration(s.vibration)
                    if (s.vibration) vibrationPattern = longArrayOf(0, 250, 120, 250)
                }
                m.createNotificationChannel(ch)
            }
            m.notificationChannels.filter { it.id.startsWith("reminders_") && it.id != id }
                .forEach { m.deleteNotificationChannel(it.id) }
        }
        return id
    }

    /**
     * Default importance (not "low"), so the note shows in the status bar and the main part of the
     * notification shade instead of the collapsed "Silent" section. It still makes no sound.
     */
    private fun pinChannel(ctx: Context): String {
        if (Build.VERSION.SDK_INT >= 26) {
            val m = nm(ctx)
            m.getNotificationChannel("pinned_notes")?.let { m.deleteNotificationChannel(it.id) } // old low-importance channel
            if (m.getNotificationChannel(CH_PIN) == null) {
                val ch = NotificationChannel(CH_PIN, "Notes pinned to the notification bar", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Keeps pinned notes in your notifications"
                    setSound(null, null)
                    enableVibration(false)
                    enableLights(false)
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                }
                m.createNotificationChannel(ch)
            }
        }
        return CH_PIN
    }

    /** True when pinned notes can actually appear (permission on and the channel not switched off). */
    fun canPin(ctx: Context): Boolean {
        if (!canPost(ctx)) return false
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = nm(ctx).getNotificationChannel(pinChannel(ctx))
            if (ch != null && ch.importance == NotificationManager.IMPORTANCE_NONE) return false
        }
        return true
    }

    /** Opens Android's notification settings for Unutma. */
    fun openSettings(ctx: Context) {
        val i = if (Build.VERSION.SDK_INT >= 26) Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        else Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName))
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openNoteIntent(ctx: Context, noteId: Int, requestOffset: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            action = MainActivity.ACTION_OPEN_NOTE
            putExtra(EXTRA_NOTE_ID, noteId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            ctx, noteId * 10 + requestOffset, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    private fun broadcast(ctx: Context, cls: Class<*>, action: String, noteId: Int, requestOffset: Int): PendingIntent {
        val i = Intent(ctx, cls).apply { this.action = action; putExtra(EXTRA_NOTE_ID, noteId) }
        return PendingIntent.getBroadcast(
            ctx, noteId * 10 + requestOffset, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    @Suppress("UNUSED_PARAMETER")
    private fun labelColorInt(ctx: Context, note: Note, labelKey: String?): Int =
        (LABEL_COLOURS.firstOrNull { it.key == (labelKey ?: Prefs.get(ctx).current.accentKey) } ?: LABEL_COLOURS[0])
            .dark.toArgb()

    // ─── Reminders ───────────────────────────────────────────────────────────

    fun showReminder(ctx: Context, note: Note, labelKey: String?) {
        if (!canPost(ctx)) return
        val blocks = parseBlocks(note)
        val title = noteDisplayTitle(note, blocks)
        val text = when {
            note.isLocked -> "Locked note"
            note.nagMinutes > 0 -> "Reminding you every ${note.nagMinutes} min until you tap Done"
            else -> blocks.previewLine().ifBlank { "Reminder" }
        }
        val b = NotificationCompat.Builder(ctx, reminderChannel(ctx))
            .setSmallIcon(R.drawable.ic_stat_unutma)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (note.isLocked) text else blocks.plainText().ifBlank { text }))
            .setColor(labelColorInt(ctx, note, labelKey))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openNoteIntent(ctx, note.id, 1))
            .addAction(0, "Done", broadcast(ctx, AlarmReceiver::class.java, AlarmReceiver.ACTION_DONE, note.id, 2))
            .addAction(0, "Snooze 10 min", broadcast(ctx, AlarmReceiver::class.java, AlarmReceiver.ACTION_SNOOZE, note.id, 3))
        if (Build.VERSION.SDK_INT < 26) {
            val s = Prefs.get(ctx).current
            var defaults = 0
            if (s.sound) defaults = defaults or NotificationCompat.DEFAULT_SOUND
            if (s.vibration) defaults = defaults or NotificationCompat.DEFAULT_VIBRATE
            b.setDefaults(defaults)
        }
        try { NotificationManagerCompat.from(ctx).notify(TAG_REMINDER, note.id, b.build()) } catch (_: SecurityException) {}
    }

    fun cancelReminder(ctx: Context, noteId: Int) {
        NotificationManagerCompat.from(ctx).cancel(TAG_REMINDER, noteId)
    }

    // ─── Pinned to the notification bar ──────────────────────────────────────

    /** Posts or removes the ongoing notification for a note, depending on its pinnedToBar flag. */
    fun syncPin(ctx: Context, note: Note, labelKey: String? = null) {
        if (!note.pinnedToBar || note.isArchived) { cancelPin(ctx, note.id); return }
        if (!canPost(ctx)) return
        val blocks = parseBlocks(note)
        val title = noteDisplayTitle(note, blocks)
        val body = if (note.isLocked) "Locked note" else blocks.plainText().ifBlank { blocks.previewLine() }
        val b = NotificationCompat.Builder(ctx, pinChannel(ctx))
            .setSmallIcon(R.drawable.ic_stat_unutma)
            .setContentTitle(title)
            .setContentText(if (note.isLocked) body else blocks.previewLine())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setColor(labelColorInt(ctx, note, labelKey))
            .setOngoing(true)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setShowWhen(false)
            .setLocalOnly(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(if (note.isLocked) NotificationCompat.VISIBILITY_SECRET else NotificationCompat.VISIBILITY_PRIVATE)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openNoteIntent(ctx, note.id, 4))
            // Android 14+ lets people swipe even ongoing notifications away; we put it straight back.
            .setDeleteIntent(broadcast(ctx, PinReceiver::class.java, PinReceiver.ACTION_DISMISSED, note.id, 5))
            .addAction(0, "Unpin", broadcast(ctx, PinReceiver::class.java, PinReceiver.ACTION_UNPIN, note.id, 6))
        val n = b.build()
        // "Clear all" must not remove it either.
        n.flags = n.flags or Notification.FLAG_NO_CLEAR or Notification.FLAG_ONGOING_EVENT
        try { NotificationManagerCompat.from(ctx).notify(TAG_PIN, note.id, n) } catch (_: SecurityException) {}
    }

    /** Puts every pinned note back in the bar (app opened, permission just granted, phone restarted…). */
    suspend fun resyncPins(ctx: Context) {
        val labels = com.example.unutma.data.Repo.labels(ctx).all()
        for (note in com.example.unutma.data.Repo.notes(ctx).activeNow()) {
            if (note.pinnedToBar) syncPin(ctx, note, labels.firstOrNull { it.id == note.labelId }?.color)
        }
    }

    fun cancelPin(ctx: Context, noteId: Int) {
        NotificationManagerCompat.from(ctx).cancel(TAG_PIN, noteId)
    }
}
