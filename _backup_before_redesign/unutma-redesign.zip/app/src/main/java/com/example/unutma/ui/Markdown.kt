package com.example.unutma.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import com.example.unutma.ui.theme.GeistMono
import com.example.unutma.util.MathEval

private val boldRe = Regex("\\*\\*(.+?)\\*\\*")
private val italicRe = Regex("(?<![*\\w])\\*(?!\\s)(.+?)(?<!\\s)\\*(?![*\\w])")
private val linkRe = Regex("\\[\\[(.+?)]]")

/** Applies bold / italic / link styles without changing the text, so the cursor maps 1:1. */
fun styleMarkdown(s: String, marker: Color, link: Color): AnnotatedString {
    val b = AnnotatedString.Builder(s)
    val taken = ArrayList<IntRange>()
    val markerStyle = SpanStyle(color = marker)
    for (m in boldRe.findAll(s)) {
        val r = m.range
        b.addStyle(SpanStyle(fontWeight = FontWeight.SemiBold), r.first, r.last + 1)
        b.addStyle(markerStyle, r.first, r.first + 2)
        b.addStyle(markerStyle, r.last - 1, r.last + 1)
        taken += r
    }
    for (m in italicRe.findAll(s)) {
        val r = m.range
        if (taken.any { it.first <= r.last && r.first <= it.last }) continue
        b.addStyle(SpanStyle(fontStyle = FontStyle.Italic), r.first, r.last + 1)
        b.addStyle(markerStyle, r.first, r.first + 1)
        b.addStyle(markerStyle, r.last, r.last + 1)
    }
    for (m in linkRe.findAll(s)) {
        val r = m.range
        b.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), r.first + 2, r.last - 1)
        b.addStyle(SpanStyle(color = link), r.first + 2, r.last - 1)
        b.addStyle(markerStyle, r.first, r.first + 2)
        b.addStyle(markerStyle, r.last - 1, r.last + 1)
    }
    return b.toAnnotatedString()
}

/** The [[title]] around [cursor], if the cursor is inside a note link. */
fun linkAt(s: String, cursor: Int): String? =
    linkRe.findAll(s).firstOrNull { cursor >= it.range.first && cursor <= it.range.last + 1 }?.groupValues?.get(1)?.trim()

/**
 * Note body rendering: markdown styles plus, with [math] on, the answer after any line
 * ending in "=" (shown in the accent colour, not part of the saved text).
 */
class NoteTransformation(
    private val marker: Color,
    private val link: Color,
    private val answer: Color,
    private val math: Boolean,
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val styled = styleMarkdown(s, marker, link)
        val inserts = if (math) MathEval.results(s) else emptyList()
        if (inserts.isEmpty()) return TransformedText(styled, OffsetMapping.Identity)

        val out = AnnotatedString.Builder()
        var last = 0
        for (ins in inserts) {
            out.append(styled.subSequence(last, ins.insertAt))
            out.pushStyle(SpanStyle(color = answer, fontFamily = GeistMono))
            out.append(ins.text)
            out.pop()
            last = ins.insertAt
        }
        out.append(styled.subSequence(last, s.length))

        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                var shift = 0
                for (ins in inserts) if (ins.insertAt < offset) shift += ins.text.length
                return offset + shift
            }

            override fun transformedToOriginal(offset: Int): Int {
                var shift = 0
                for (ins in inserts) {
                    val start = ins.insertAt + shift
                    if (offset <= start) break
                    if (offset < start + ins.text.length) return ins.insertAt
                    shift += ins.text.length
                }
                return (offset - shift).coerceIn(0, s.length)
            }
        }
        return TransformedText(out.toAnnotatedString(), mapping)
    }

    override fun equals(other: Any?): Boolean =
        other is NoteTransformation && other.marker == marker && other.link == link && other.answer == answer && other.math == math

    override fun hashCode(): Int = marker.hashCode() * 31 + link.hashCode() * 7 + answer.hashCode() + if (math) 1 else 0
}
