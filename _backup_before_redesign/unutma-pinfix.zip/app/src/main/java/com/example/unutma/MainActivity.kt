package com.example.unutma

import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color as AColor
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.unutma.data.Prefs
import com.example.unutma.data.Repo
import com.example.unutma.data.Settings
import com.example.unutma.data.ThemeMode
import com.example.unutma.data.noteDisplayTitle
import com.example.unutma.notify.Notifier
import com.example.unutma.ui.ArchiveScreen
import com.example.unutma.ui.EditorScreen
import com.example.unutma.ui.EditorTarget
import com.example.unutma.ui.LabelsScreen
import com.example.unutma.ui.NotesScreen
import com.example.unutma.ui.SettingsScreen
import com.example.unutma.ui.theme.C
import com.example.unutma.ui.theme.UnutmaTheme
import kotlinx.coroutines.launch

/** The screens of the app. */
sealed interface Route {
    data object Notes : Route
    data class Edit(val target: EditorTarget) : Route
    data object Settings : Route
    data object Archive : Route
    data object Labels : Route
}

class MainActivity : ComponentActivity() {
    companion object {
        const val ACTION_OPEN_NOTE = "com.example.unutma.OPEN_NOTE"
        const val ACTION_NEW_NOTE = "com.example.unutma.NEW_NOTE"
        const val ACTION_NEW_LIST = "com.example.unutma.NEW_LIST"
        const val ACTION_VOICE = "com.example.unutma.VOICE"
    }

    /** The latest intent from a widget or notification, handled by the UI. */
    private val incoming = mutableStateOf<Intent?>(null)

    // Unlocking on Android 7–9 uses the lock screen's own confirm screen.
    private var onUnlocked: (() -> Unit)? = null
    private lateinit var credentialLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        credentialLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == RESULT_OK) onUnlocked?.invoke()
            onUnlocked = null
        }
        if (savedInstanceState == null) incoming.value = intent
        Repo.scope.launch {
            com.example.unutma.data.Guide.seedIfNeeded(applicationContext) // guide notes on first launch
            Repo.maintenance(applicationContext)
        }

        setContent {
            val settings by Prefs.get(this).state.collectAsState()
            val dark = when (settings.themeMode) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            LaunchedEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT) else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT),
                    navigationBarStyle = if (dark) SystemBarStyle.dark(AColor.TRANSPARENT) else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT),
                )
            }
            UnutmaTheme(darkTheme = dark, accentKey = settings.accentKey, textScale = settings.textSize.scale) {
                UnutmaApp(settings, incoming, ::unlock)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // If a pinned note was removed from the bar (cleaner app, permission granted later…), put it back.
        Repo.scope.launch { Notifier.resyncPins(applicationContext) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        incoming.value = intent
    }

    /** Fingerprint/face or the phone's PIN, pattern or password. */
    fun unlock(onSuccess: () -> Unit) {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isDeviceSecure) {
            Toast.makeText(this, "Set a screen lock on your phone to protect locked notes.", Toast.LENGTH_LONG).show()
            onSuccess(); return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val prompt = BiometricPrompt.Builder(this)
                .setTitle("Unlock note")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                .build()
            prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { onSuccess() }
            })
        } else {
            @Suppress("DEPRECATION")
            val i = km.createConfirmDeviceCredentialIntent("Unlock note", null)
            if (i == null) { onSuccess(); return }
            onUnlocked = onSuccess
            credentialLauncher.launch(i)
        }
    }
}

@Composable
fun UnutmaApp(settings: Settings, incoming: MutableState<Intent?>, unlock: (() -> Unit) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val notes by remember { Repo.notes(ctx).observeActive() }.collectAsState(initial = emptyList())
    val archived by remember { Repo.notes(ctx).observeArchived() }.collectAsState(initial = emptyList())
    val labels by remember { Repo.labels(ctx).observeAll() }.collectAsState(initial = emptyList())
    val stack = remember { mutableStateListOf<Route>(Route.Notes) }

    fun push(r: Route) { stack.add(r) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun openEditor(t: EditorTarget) {
        // Opening a note from another note replaces the editor instead of stacking many.
        if (stack.last() is Route.Edit) stack[stack.lastIndex] = Route.Edit(t) else push(Route.Edit(t))
    }

    fun open(note: Note) {
        if (note.isLocked) unlock { openEditor(EditorTarget(note.id)) } else openEditor(EditorTarget(note.id))
    }

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) scope.launch {
            val n = Repo.createFromSpeech(ctx, text, preferList = false)
            openEditor(EditorTarget(n.id))
        }
    }
    fun talk() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a note — or “shopping list eggs, milk and bread”")
        try { speech.launch(i) } catch (_: ActivityNotFoundException) {
            Toast.makeText(ctx, "Speech recognition isn't available on this phone.", Toast.LENGTH_LONG).show()
        }
    }

    fun feedback() {
        val i = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_SUBJECT, "Unutma – feedback")
        }
        try { ctx.startActivity(i) } catch (_: ActivityNotFoundException) {
            Toast.makeText(ctx, "No email app found.", Toast.LENGTH_SHORT).show()
        }
    }

    // Widgets and notifications
    val pending = incoming.value
    LaunchedEffect(pending) {
        val i = pending ?: return@LaunchedEffect
        incoming.value = null
        when (i.action) {
            MainActivity.ACTION_OPEN_NOTE -> {
                val id = i.getIntExtra(Notifier.EXTRA_NOTE_ID, -1)
                val n = if (id > 0) Repo.notes(ctx).get(id) else null
                if (n != null && !n.isArchived) { stack.retainAll { it == Route.Notes }; open(n) }
            }
            MainActivity.ACTION_NEW_NOTE -> { stack.retainAll { it == Route.Notes }; openEditor(EditorTarget(0, NOTE_TYPE_TEXT)) }
            MainActivity.ACTION_NEW_LIST -> { stack.retainAll { it == Route.Notes }; openEditor(EditorTarget(0, NOTE_TYPE_LIST)) }
            MainActivity.ACTION_VOICE -> talk()
        }
    }

    BackHandler(enabled = stack.size > 1) { pop() }

    Box(Modifier.fillMaxSize().background(C.bg)) {
        when (val r = stack.last()) {
            Route.Notes -> NotesScreen(
                notes = notes,
                labels = labels,
                sortOrder = settings.sortOrder,
                onOpen = ::open,
                onNew = { type, labelId -> openEditor(EditorTarget(0, type, labelId)) },
                onVoice = ::talk,
                onArchive = { push(Route.Archive) },
                onLabels = { push(Route.Labels) },
                onSettings = { push(Route.Settings) },
                onFeedback = ::feedback,
                onSetLabel = { ids, labelId -> scope.launch { Repo.saveAll(ctx, notes.filter { it.id in ids }.map { it.copy(labelId = labelId) }) } },
                onTogglePinTop = { ids ->
                    val chosen = notes.filter { it.id in ids }
                    val pin = !chosen.all { it.isPinned }
                    scope.launch { Repo.saveAll(ctx, chosen.map { it.copy(isPinned = pin) }) }
                },
                onArchiveNotes = { ids -> scope.launch { Repo.archive(ctx, ids, deleted = false) } },
                onDeleteNotes = { ids -> scope.launch { Repo.delete(ctx, ids) } },
            )
            is Route.Edit -> EditorScreen(
                target = r.target,
                labels = labels,
                allNotes = notes,
                onBack = ::pop,
                onOpenLink = { title ->
                    val found = notes.firstOrNull { noteDisplayTitle(it).equals(title, ignoreCase = true) }
                    if (found != null) open(found) else openEditor(EditorTarget(0, NOTE_TYPE_TEXT, title = title))
                },
                onManageLabels = { push(Route.Labels) },
                unlock = unlock,
            )
            Route.Settings -> SettingsScreen(settings, { change -> Prefs.get(ctx).update(change) }, ::pop, ::feedback)
            Route.Archive -> ArchiveScreen(
                notes = archived,
                labels = labels,
                archiveDays = settings.archiveDays,
                onBack = ::pop,
                onRestore = { n -> scope.launch { Repo.restore(ctx, listOf(n.id)) } },
                onDeleteForever = { ids -> scope.launch { Repo.deleteForever(ctx, ids) } },
            )
            Route.Labels -> LabelsScreen(
                labels = labels,
                counts = notes.groupingBy { it.labelId ?: -1 }.eachCount(),
                onBack = ::pop,
                onAdd = { name, color ->
                    scope.launch { Repo.labels(ctx).insert(Label(name = name, color = color, position = (labels.maxOfOrNull { it.position } ?: 0) + 1)) }
                },
                onUpdate = { l -> scope.launch { Repo.labels(ctx).update(l); com.example.unutma.widget.Widgets.refreshAll(ctx) } },
                onDelete = { l ->
                    scope.launch {
                        Repo.notes(ctx).clearLabel(l.id)
                        Repo.labels(ctx).delete(l)
                        com.example.unutma.widget.Widgets.refreshAll(ctx)
                    }
                },
                onMove = { l, to ->
                    val list = labels.toMutableList()
                    val from = list.indexOfFirst { it.id == l.id }
                    if (from >= 0 && to in list.indices) {
                        list.add(to, list.removeAt(from))
                        scope.launch { list.forEachIndexed { i, x -> if (x.position != i) Repo.labels(ctx).update(x.copy(position = i)) } }
                    }
                },
            )
        }
    }
}
